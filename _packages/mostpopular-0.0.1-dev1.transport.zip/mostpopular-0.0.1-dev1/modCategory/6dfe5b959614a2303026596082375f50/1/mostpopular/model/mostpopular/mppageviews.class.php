<?php
/**
 * @package mostpopular
 */
class MPPageViews extends xPDOSimpleObject {}
?>